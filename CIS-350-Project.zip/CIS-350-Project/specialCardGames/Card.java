package specialCardGames;

public class Card {

}
